/*jslint node: true */
"use strict";

function onMessage(data) {
    console.log(data);
    // Do something, you just received a message ;)
}

module.exports = {
    onMessage: onMessage
};
